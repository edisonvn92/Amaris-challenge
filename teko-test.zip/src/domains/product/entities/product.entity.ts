// Generate code from clean architecture template
/* eslint-disable @typescript-eslint/no-empty-interface */

export interface ProductEntity {
    id: number,
    name: string,
    image: string,
    price: number,
    discountPercent?: number,
    seller?: string,
    availableQuantity?: number,
    relatedProducts?: ProductEntity[]
}
