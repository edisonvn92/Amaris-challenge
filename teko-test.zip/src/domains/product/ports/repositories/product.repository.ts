// Generate code from clean architecture template

import { CreateProductPayload, QueryProductPayload } from '../payloads';
import { ProductEntity } from '../../entities';

export interface ProductRepository {
  create(payload: CreateProductPayload): Promise<ProductEntity>;
  findAll(payload: QueryProductPayload): Promise<ProductEntity[]>;
  findOne(id: string): Promise<ProductEntity>;
}
