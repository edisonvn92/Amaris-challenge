// Generate code from clean architecture template

import { ProductEntity } from '../entities';
import { QueryProductPayload } from '../ports/payloads';
import { ProductRepository } from '../ports/repositories';

export class FindOneProductUsecase {
  constructor(private readonly repo: ProductRepository) {}

  async run(id: string): Promise<ProductEntity> {
    return this.repo.findOne(id);
  }
}
