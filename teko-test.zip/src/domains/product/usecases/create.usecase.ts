// Generate code from clean architecture template

import { ProductEntity } from '../entities';
import { CreateProductPayload } from '../ports/payloads';
import { ProductRepository } from '../ports/repositories';

export class CreateProductUsecase {
  constructor(private readonly repo: ProductRepository) {}

  async run(payload: CreateProductPayload): Promise<ProductEntity> {
    throw new Error('Method not implemented.');
  }
}
