import { Button as AntButton } from 'antd';

export const Button = AntButton;
