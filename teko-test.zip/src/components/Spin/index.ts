import { Spin } from 'antd';

export { Spin };
