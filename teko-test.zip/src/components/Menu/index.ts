import { Menu } from 'antd';
import type { MenuProps } from 'antd';

export { Menu };
export type { MenuProps };
