import { Layout } from 'antd';

export { Layout };
