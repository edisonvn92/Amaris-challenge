import { config } from '@/config';

export const { apiUrl } = config.base;

console.log({ apiUrl });
