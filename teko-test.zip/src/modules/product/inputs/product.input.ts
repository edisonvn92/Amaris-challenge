// Generate code from clean architecture template
/* eslint-disable @typescript-eslint/no-empty-interface */

export interface CreateProductInput {
  // todo
}

export interface UpdateProductInput {
  // todo
}
