export * from './product.input';
