import React, { useEffect } from 'react';
import useViewModel from '../viewmodels/product.viewmodel';
import { useParams } from 'react-router-dom';
import { PageProvider } from '@/common/context/PageContext';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const ProductDetailProvider = (props: any) => {
  const { children } = props;
  const params = useParams();
  const { productDetail, getProductDetail } = useViewModel();

  useEffect(() => {
    getProductDetail('1')
  }, []);

  const data = {
    productDetail,
    getProductDetail
  };

  return <PageProvider {...data}>{children}</PageProvider>;
};