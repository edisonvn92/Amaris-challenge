// Generate code from clean architecture template

import { FindOneProductUsecase } from '@/domains/product/usecases';
import { ProductHttpRepository } from '../adapters/repositories';
import { ProductEntity } from '@/domains/product/entities';
import { useState } from 'react';

export default function ProductViewModel() {
  const findOneUC = new FindOneProductUsecase(new ProductHttpRepository());
  const [productDetail, setProductDetail] = useState<ProductEntity| undefined>(undefined)

  const getProductDetail = async (id: string) => {
    const detail = await findOneUC.run(id);
    setProductDetail(detail);
  }

  return {
    productDetail,
    getProductDetail
  }
}
