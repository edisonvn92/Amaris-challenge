import { useCoreContext } from '@/common';
import { ProductEntity } from '@/domains/product/entities';
import React from 'react';
import { ProductItemCard } from '../../components/ProductItemCard';
import { priceDecoration } from '../../helpers/priceDecoration';

export const ProductDetailScreen: React.FC = () => {
    const { productDetail } = useCoreContext();
    
    return <div className='bg-white w-full p-4'>
        {productDetail ? <div>
            <img src={productDetail.image} className='w-full'/>
            <h1 className='text-red-600 font-bold text-2xl'>{priceDecoration(productDetail.price)}</h1>
            <div className='flex'>
                <p className='text-gray-600 line-through mr-2'>{priceDecoration((productDetail.price * (1 + productDetail.discountPercent/100)).toFixed(0))}</p>
                <p className='text-red-600'>-{productDetail.discountPercent}%</p>
            </div>
            <div className='font-700 font-bold'>{productDetail.name}</div>
            <div>By <a>{productDetail.seller}</a></div>
            <p className='font-bold'>Sản phẩm liên quan</p>
            <div className='flex overflow-x-scroll gap-4'>
            {(productDetail.relatedProducts || []).map((product: ProductEntity) => <ProductItemCard product={product} />)}
            </div>
            
        </div> : undefined}

    </div>
}

