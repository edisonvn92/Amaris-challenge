import React from 'react';
import { ProductDetailProvider } from '../../context/ProductDetailProvider';
import { ProductDetailScreen } from './ProductDetailScreen';

export const ProductDetail: React.FC = () => {
    return <ProductDetailProvider>
        <ProductDetailScreen />
    </ProductDetailProvider>
}