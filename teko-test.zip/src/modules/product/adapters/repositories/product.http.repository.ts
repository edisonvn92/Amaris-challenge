// Generate code from clean architecture template

import { ProductEntity } from "@/domains/product/entities";
import { CreateProductPayload, QueryProductPayload } from "@/domains/product/ports/payloads";
import { ProductRepository } from "@/domains/product/ports/repositories";
import { mockData } from "./mockData";


export class ProductHttpRepository implements ProductRepository {
    create(payload: CreateProductPayload): Promise<ProductEntity> {
        throw new Error("Method not implemented.");
    }
    findAll(payload: QueryProductPayload): Promise<ProductEntity[]> {
        throw new Error("Method not implemented.");
    }
    findOne(id: number): Promise<ProductEntity> {
        return Promise.resolve(mockData);
    }
}
