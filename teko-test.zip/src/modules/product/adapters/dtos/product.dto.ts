// Generate code from clean architecture template
/* eslint-disable @typescript-eslint/no-empty-interface */

export interface CreateProductDto {
  // todo
}

export interface UpdateProductDto {
  // todo
}
