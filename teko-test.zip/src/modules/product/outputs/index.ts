export * from './product.output';
