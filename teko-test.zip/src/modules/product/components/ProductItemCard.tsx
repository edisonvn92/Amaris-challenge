import { ProductEntity } from '@/domains/product/entities';
import React from 'react';
import { priceDecoration } from '../helpers/priceDecoration';

interface ProductItemProps {
    product: ProductEntity
}
export const ProductItemCard: React.FC<ProductItemProps> = (props: ProductItemProps) => {
    const { product } = props;
    return <div className='bg-white w-[200px] border border-solid border-gray-200 rounded-lg p-4'>
        <img src={product.image} className='w-full' />
        <div className='truncate'>{product.name}</div>
        <div className='text-orange-600'>Còn {product.availableQuantity} sản phẩm</div>
        <h1 className='text-red-600 font-bold'>{priceDecoration(product.price)}</h1>
        {product.discountPercent ? <div className='flex'>
            <p className='text-gray-600 line-through mr-2'>{priceDecoration((product.price * (1 + (product.discountPercent || 0) / 100)).toFixed(0))}</p>
            <p className='text-red-600'>-{product.discountPercent}%</p>
        </div> : <div className='h-9' />}
        <button className='border border-red-600 text-red-600 bg-white rounded-lg w-full p-2 font-boldx'>Thêm vào giỏ</button>


    </div>
}