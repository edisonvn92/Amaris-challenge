import {
  DesktopOutlined,
  FileOutlined,
  PieChartOutlined,
  TeamOutlined,
  UserOutlined,
  RedditOutlined,
  IdcardOutlined,
} from '@ant-design/icons';

export {
  DesktopOutlined,
  FileOutlined,
  PieChartOutlined,
  TeamOutlined,
  UserOutlined,
  RedditOutlined,
  IdcardOutlined,
};
