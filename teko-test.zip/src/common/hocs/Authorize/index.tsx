import React from 'react';
import { useSSOAuthentication } from '@/common/hooks';
import { Spin, FullView } from '@/components';

import './index.css';

export const Authorize =
  (Component: React.FC): React.FC =>
  () => {
    const { isAuthenticated } = useSSOAuthentication(true);
    if (isAuthenticated) {
      return <Component />;
    }
    return (
      <FullView className="container-center">
        <Spin />
      </FullView>
    );
  };
