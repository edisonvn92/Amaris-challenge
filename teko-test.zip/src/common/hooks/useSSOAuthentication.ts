import { useEffect, useState } from 'react';
import { getCustomTokenFromSSOServer, authenticate, navigateOnFailures } from '@/common';
import '@/common/firebase';

export const useSSOAuthentication = (authenticationRequired: boolean) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | undefined>(undefined);

  const execSSOAuthenticate = async () => {
    try {
      const customToken = await getCustomTokenFromSSOServer();
      const { userId: newUserId } = await authenticate(customToken);

      if (newUserId) {
        setIsAuthenticated(true);
      } else {
        // setIsAuthorized(false);
      }
    } catch (error) {
      setIsAuthenticated(false);
    }
  };

  useEffect(() => {
    if (!isAuthenticated) {
      execSSOAuthenticate();
    }
  }, []);

  navigateOnFailures(isAuthenticated, authenticationRequired);

  return {
    isAuthenticated,
  };
};
