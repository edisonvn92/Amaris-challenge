import { defaultsDeep } from 'lodash';
import { overrideConfig } from './override.config';

export interface Config {
  title: string;
  footer: {
    text: string;
  };
  firebase: {
    apiKey: string;
    authDomain: string;
    databaseURL: string;
    projectId: string;
    storageBucket: string;
    messagingSenderId: string;
    appId: string;
    measurementId: string;
  };
  base: {
    webUrl: string;
    apiUrl: string;
  };
}

const defaultConfig: Config = {
  title: import.meta.env.VITE_APP_TITLE || 'MindX Technology School',
  footer: {
    text: import.meta.env.VITE_APP_FOOTER_TEXT || 'MindX Technology School 2022',
  },
  firebase: {
    apiKey: import.meta.env.VITE_FIREBASE_API_KEY || 'AIzaSyB-x8gFuVKzbIoB1aYKbG1jrvm8mbZUmkQ',
    authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || 'mindx-edu-dev.firebaseapp.com',
    databaseURL:
      import.meta.env.VITE_FIREBASE_DATABASE_URL || 'https://mindx-edu-dev.firebaseio.com',
    projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || 'mindx-edu-dev',
    storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || 'mindx-edu-dev.appspot.com',
    messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGE_SENDER_ID || '592744290445',
    appId: import.meta.env.VITE_FIREBASE_APP_ID || '1:592744290445:web:aa82213d363f9b59c5eac4',
    measurementId: import.meta.env.VITE_FIREBASE_MESSAGE_SENDER_ID || 'G-QPEELWB8Q4',
  },
  base: {
    webUrl: import.meta.env.VITE_BASE_WEB_URL || 'https://base-dev.mindx.edu.vn',
    apiUrl:
      import.meta.env.VITE_BASE_API_URL ||
      'https://gateway-staging.mindx.edu.vn/crm-v2-api/graphql',
  },
};

export const config = defaultsDeep(overrideConfig, defaultConfig) as Config;
