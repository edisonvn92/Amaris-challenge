import React, { useState } from 'react';
import { Routes, Route, Link, useNavigate, Navigate } from 'react-router-dom';
import { IdcardOutlined, RedditOutlined } from './icons';
import { config } from './config';
import type { MenuProps } from './components';
import { Layout, Menu } from './components';
import { useDocumentTitle } from './common';

import './App.css';
import './index.css';
import { ProductDetail } from './modules/product/screens/ProductDetail';

const { Header, Content, Footer, Sider } = Layout;

type MenuItem = Required<MenuProps>['items'][number];

const getItem = (
  label: React.ReactNode,
  key: React.Key,
  icon?: React.ReactNode,
  children?: MenuItem[],
): MenuItem =>
  ({
    key,
    icon,
    children,
    label,
  } as MenuItem);

const items: MenuItem[] = [
  getItem('Customer needs', '/customer-needs', <RedditOutlined />),
  getItem('Jobs', '/jobs', <IdcardOutlined />),
];

const App: React.FC = () => {
  const [collapsed, setCollapsed] = useState(false);
  useDocumentTitle();
  const navigate = useNavigate();
  return (
    <Layout style={{ minHeight: '100vh' }}>
      <Layout className="site-layout">
        <Content style={{ margin: '0 16px' }}>
          <Routes>
            <Route path="" element={<Navigate to="/products/1" />}/> 
            <Route path="/products">
              <Route path=':id' element={<ProductDetail />}/>
            </Route>
          </Routes>
        </Content>
        <Footer style={{ textAlign: 'center' }}>{config.footer.text}</Footer>
      </Layout>
    </Layout>
  );
};

export default App;